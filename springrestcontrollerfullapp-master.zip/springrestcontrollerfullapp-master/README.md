# Enunciado da Atividade
1. Clone o repositório

1. Abra o projeto, que é implementado em Java com Spring Boot e Maven

1. Responda às questões abaixo:
    1. Quais são os endpoint implementados?
    2. Quais são as entradas destes endpoints (tipos e formatos)?
    3. Quais são as saídas?
1. Testem cada endpoint.
1. Implemente uma funcionalidade simples de Login, que suporte:
    1. criação de usuários com senha
        1. não permitir usuário duplicados
    1. fazer Login
       1. só permitir acesso aos endpoints se houver algum usuário conectado.
